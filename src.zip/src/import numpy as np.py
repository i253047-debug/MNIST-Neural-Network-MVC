import numpy as np
import matplotlib.pyplot as plt
import os
import urllib.request

# ==========================================================
# 1. DATA LOADING & PREPROCESSING (Task 5 Logic)
# ==========================================================
def load_mnist():
    mnist_url = "https://storage.googleapis.com/tensorflow/tf-keras-datasets/mnist.npz"
    data_path = "mnist.npz"
    
    if not os.path.exists(data_path):
        print("Downloading MNIST... (this takes 1-2 minutes)")
        urllib.request.urlretrieve(mnist_url, data_path)
        print("Download complete.")
    else:
        print("MNIST already exists, loading...")
    
    data = np.load(data_path)
    # Normalize pixels to [0, 1] and flatten 28x28 to 784
    X_train = data['x_train'].reshape(-1, 784) / 255.0
    Y_train = data['y_train']
    X_test  = data['x_test'].reshape(-1, 784) / 255.0
    Y_test  = data['y_test']
    
    return X_train, Y_train, X_test, Y_test

def to_one_hot(labels, num_classes=10):
    m = len(labels)
    one_hot = np.zeros((m, num_classes))
    one_hot[np.arange(m), labels] = 1
    return one_hot

# Load data
X_train, Y_train, X_test, Y_test = load_mnist()
Y_train_oh = to_one_hot(Y_train)
Y_test_oh  = to_one_hot(Y_test)

# ==========================================================
# 2. NEURAL NETWORK CLASS (Tasks 1, 3, 6A, 7)
# ==========================================================
class MNISTNetwork:
    def __init__(self, layers=[784, 128, 64, 10], lr=0.1, beta=0.9):
        self.lr = lr
        self.beta = beta
        
        # Task 1: Initialize Weights and Biases
        np.random.seed(42)
        self.W1 = np.random.uniform(-0.1, 0.1, (layers[0], layers[1]))
        self.b1 = np.zeros((1, layers[1]))
        self.W2 = np.random.uniform(-0.1, 0.1, (layers[1], layers[2]))
        self.b2 = np.zeros((1, layers[2]))
        self.W3 = np.random.uniform(-0.1, 0.1, (layers[2], layers[3]))
        self.b3 = np.zeros((1, layers[3]))

        # Task 6A: Initialize Velocities for Momentum
        self.vW1, self.vb1 = np.zeros_like(self.W1), np.zeros_like(self.b1)
        self.vW2, self.vb2 = np.zeros_like(self.W2), np.zeros_like(self.b2)
        self.vW3, self.vb3 = np.zeros_like(self.W3), np.zeros_like(self.b3)

    def sigmoid(self, z):
        return 1.0 / (1.0 + np.exp(-np.clip(z, -500, 500)))

    def sigmoid_derivative(self, a):
        return a * (1.0 - a)

    def forward(self, X):
        # Task 1 & 2: Forward Pass
        self.Z1 = X @ self.W1 + self.b1
        self.A1 = self.sigmoid(self.Z1)
        
        self.Z2 = self.A1 @ self.W2 + self.b2
        self.A2 = self.sigmoid(self.Z2)
        
        self.Z3 = self.A2 @ self.W3 + self.b3
        self.A3 = self.sigmoid(self.Z3)
        return self.A3

    def backward(self, X, Y_true):
        # Task 3: Backpropagation (Chain Rule)
        m = X.shape[0]

        # Output Layer
        delta3 = (self.A3 - Y_true) * self.sigmoid_derivative(self.A3)
        dW3 = (self.A2.T @ delta3) / m
        db3 = np.mean(delta3, axis=0, keepdims=True)

        # Hidden Layer 2
        delta2 = (delta3 @ self.W3.T) * self.sigmoid_derivative(self.A2)
        dW2 = (self.A1.T @ delta2) / m
        db2 = np.mean(delta2, axis=0, keepdims=True)

        # Hidden Layer 1
        delta1 = (delta2 @ self.W2.T) * self.sigmoid_derivative(self.A1)
        dW1 = (X.T @ delta1) / m
        db1 = np.mean(delta1, axis=0, keepdims=True)

        return dW1, db1, dW2, db2, dW3, db3

    def update_parameters(self, grads):
        dW1, db1, dW2, db2, dW3, db3 = grads

        # Task 6A: Momentum Velocity Updates
        self.vW1 = self.beta * self.vW1 + (1 - self.beta) * dW1
        self.vb1 = self.beta * self.vb1 + (1 - self.beta) * db1
        self.vW2 = self.beta * self.vW2 + (1 - self.beta) * dW2
        self.vb2 = self.beta * self.vb2 + (1 - self.beta) * db2
        self.vW3 = self.beta * self.vW3 + (1 - self.beta) * dW3
        self.vb3 = self.beta * self.vb3 + (1 - self.beta) * db3

        # Apply Updates to ALL weights and biases
        self.W1 -= self.lr * self.vW1
        self.b1 -= self.lr * self.vb1
        self.W2 -= self.lr * self.vW2
        self.b2 -= self.lr * self.vb2
        self.W3 -= self.lr * self.vW3
        self.b3 -= self.lr * self.vb3

# ==========================================================
# 3. TRAINING LOOP (Task 5 & 7 Execution)
# ==========================================================
nn = MNISTNetwork(lr=0.5, beta=0.9) # Higher LR for Sigmoid on MNIST
epochs = 10
batch_size = 64
loss_history = []

print(f"Architecture: 784 -> 128 -> 64 -> 10")
print("Starting Training...")

for epoch in range(epochs):
    # Task 5: Random Shuffling
    idx = np.random.permutation(X_train.shape[0])
    X_shuf, Y_shuf = X_train[idx], Y_train_oh[idx]

    for start in range(0, X_train.shape[0], batch_size):
        end = start + batch_size
        X_b, Y_b = X_shuf[start:end], Y_shuf[start:end]
        
        nn.forward(X_b)
        grads = nn.backward(X_b, Y_b)
        nn.update_parameters(grads)

    # Calculate Loss for the Epoch
    predictions = nn.forward(X_train)
    mse = np.mean((Y_train_oh - predictions)**2)
    loss_history.append(mse)
    print(f"Epoch {epoch+1}/{epochs} | Loss: {mse:.6f}")

# ==========================================================
# 4. EVALUATION & VISUALIZATION
# ==========================================================
# Final Test Accuracy
test_preds = np.argmax(nn.forward(X_test), axis=1)
accuracy = np.mean(test_preds == Y_test) * 100
print(f"\nFinal Test Accuracy: {accuracy:.2f}%")

# Plot Loss Curve
plt.figure(figsize=(8, 4))
plt.plot(range(1, epochs+1), loss_history, marker='o', color='blue')
plt.title('Training Loss - Momentum Optimizer (Task 7)')
plt.xlabel('Epoch')
plt.ylabel('MSE Loss')
plt.grid(True)
plt.show()

# Sample Predictions
fig, axes = plt.subplots(1, 5, figsize=(12, 3))
for i in range(5):
    idx = np.random.randint(0, X_test.shape[0])
    img = X_test[idx].reshape(28, 28)
    pred = np.argmax(nn.forward(X_test[idx:idx+1]))
    axes[i].imshow(img, cmap='gray')
    axes[i].set_title(f"True: {Y_test[idx]}\nPred: {pred}")
    axes[i].axis('off')
plt.tight_layout()
plt.show()